package br.imepac.edu.clinica_medica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaMedicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
